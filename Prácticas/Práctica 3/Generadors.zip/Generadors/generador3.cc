#include <iostream>
#include <vector>
using namespace std;
#include <random>
#include <fstream>

int main() {
	ofstream fichero_salida;
	fichero_salida.open("problem3.pddl");

	std::random_device rd;
	std::mt19937 eng(rd()); 
	std::uniform_int_distribution<> distr(1, 15); 
	int reservas = distr(eng);  
	vector<string> reservass (reservas);
    
    //problema
	fichero_salida << "(define (problem extensio3) (:domain planificador)" << endl;
    
    fichero_salida << endl;
	
    //constantes del problema
    fichero_salida << "		(:objects ";	
    
    //reservas
	for(int i = 0; i < reservas; ++i) {
    	string aux = "";	
    	aux.append("c");
    	reservass[i] = aux.append(to_string(i));
    	fichero_salida <<	reservass[i] << " ";	
	}	
	fichero_salida << "- reserva" << endl;
	fichero_salida << "		          ";
	
    
    std::random_device rd2;
	std::mt19937 eng2(rd2()); 
	std::uniform_int_distribution<> distr2(1, 10); 
	int hab = distr2(eng2);  
    //habitaciones
    vector<string> habitaciones (hab);
	for(int i = 0; i < hab; ++i) {
    	string aux = "";	
    	aux.append("h");
    	habitaciones[i] = aux.append(to_string(i));
    	fichero_salida <<	habitaciones[i] << " ";	
	}
	fichero_salida << "- habitacion" << endl;
    
    fichero_salida << "		)" << endl;
    
    fichero_salida << endl;
    
    //estado inicial del problema
	fichero_salida << "		(:init" << endl;
    
    //random
    srand((unsigned) time(0));
    
    //genera el numero de personas de las reservas (entre 0 y 4)
	for(int index = 0; index < reservass.size(); ++index){
	    fichero_salida << "		          (= (personas " << reservass[index] << ") " << (rand()%4)+1 << ")" << endl;
	}

	//genera la capacidad de las habitaciones (entre 0 y 4)
	for(int i = 0; i < habitaciones.size(); ++i){
		fichero_salida << "		          (= (capacidad " << habitaciones[i] << ") " << (rand()%4)+1 << ")" << endl;
	}
	
    //genera los dias de inicio y dias de final de las reservas (entre 0 y 30) 
	for(int i = 0; i < reservass.size(); ++i) {
        int d_inicio = (rand()%30) + 1;
		fichero_salida << "		          (= (dia_inicio " << reservass[i] << ") " << d_inicio << ")" << endl;
        int d_final = (rand()%30) + d_inicio;
        if (d_final > 30) d_final = 30;
        fichero_salida << "		          (= (dia_final " << reservass[i] << ") " << d_final << ")" << endl;
	}
	
	//genera el contador
	fichero_salida << "		          (= (comptador) 0)" << endl;
    
    //genera el contador de plazas
	fichero_salida << "		          (= (comptadorPlaces) 0)" << endl;

    //objetivo del problema
	fichero_salida << "		)" << endl;
	fichero_salida << endl;
    fichero_salida << "		(:goal" << endl; 
	fichero_salida << "		          (and (forall (?x - reserva) (or (servido ?x) (imposible ?x)) ))" << endl;
    fichero_salida << "		)" << endl;
    
    //metric del problema
    fichero_salida << endl;
    fichero_salida << "		(:metric minimize (+ (comptadorPlaces) (* (comptador) 8)))" << endl;
    fichero_salida << ")" << endl;
} 
 
